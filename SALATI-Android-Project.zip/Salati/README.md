# SALATI (صلاتي) — Android project foundation

A native Android project targeting API 36 (Android 16), minimum API 26 (Android 8.0), using Kotlin, Jetpack Compose, Material 3, Room, DataStore, Hilt, Navigation Compose and the Adhan calculation library.

## Included in this first project milestone
- Android Studio / Gradle project structure and dependencies.
- Compose dashboard with five persistent prayer checkboxes.
- Room database with one unique record per ISO calendar date.
- Derived streak calculation that avoids awarding a new day just because midnight passed, and does not penalize an unfinished current day.
- Offline prayer-time calculation integration using the Adhan library (calculation method and Asr madhhab are currently defaults, not yet user-configurable).
- Calendar/history and basic statistics screens.
- Notification receiver declarations and permissions as integration scaffolding.
- Unit tests for key streak cases.

## Important status
This is **not yet the complete production app requested** and no APK is included. Prayer-time display wiring, Morocco-specific official method verification, alarm scheduling/rescheduling, Android 13+ permission flow, exact-alarm access handling, Adhan playback, per-prayer reminder preferences, full calendar editing, achievements, localization, backup/restore, Hilt modules, DataStore settings, and device testing still need implementation. Those are deliberately not represented as working features.

## Build
1. Open this folder in Android Studio (a recent version supporting AGP 8.10.1 and API 36).
2. Install Android SDK Platform 36 and Android SDK Build-Tools through SDK Manager.
3. Sync Gradle.
4. Run unit tests: `./gradlew test`.
5. Build debug APK: `./gradlew assembleDebug`.
6. APK output, after a successful build: `app/build/outputs/apk/debug/app-debug.apk`.

The build environment used to prepare this source did not contain Android SDK or Gradle, so compilation and APK generation could not be verified here.
