package com.salati.app.data

import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class PrayerRepository(private val dao: PrayerDao) {
    fun observeRecords(): Flow<List<PrayerRecord>> = dao.observeAll()
    suspend fun recordFor(date: LocalDate): PrayerRecord = dao.get(date.toString()) ?: PrayerRecord(date.toString())
    suspend fun setPrayer(date: LocalDate, prayer: String, completed: Boolean) {
        val old = recordFor(date)
        val updated = when (prayer) {
            "Fajr" -> old.copy(fajrCompleted = completed)
            "Dhuhr" -> old.copy(dhuhrCompleted = completed)
            "Asr" -> old.copy(asrCompleted = completed)
            "Maghrib" -> old.copy(maghribCompleted = completed)
            "Isha" -> old.copy(ishaCompleted = completed)
            else -> error("Unknown prayer: $prayer")
        }
        dao.save(updated)
    }
}
