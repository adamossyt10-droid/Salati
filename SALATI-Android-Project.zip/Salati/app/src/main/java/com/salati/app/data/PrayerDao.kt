package com.salati.app.data

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface PrayerDao {
    @Upsert suspend fun save(record: PrayerRecord)
    @Query("SELECT * FROM prayer_records WHERE date = :date LIMIT 1") suspend fun get(date: String): PrayerRecord?
    @Query("SELECT * FROM prayer_records ORDER BY date DESC") fun observeAll(): Flow<List<PrayerRecord>>
    @Query("SELECT * FROM prayer_records ORDER BY date DESC") suspend fun all(): List<PrayerRecord>
}
