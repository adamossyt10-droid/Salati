package com.salati.app.domain

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.DateComponents
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Offline calculation using the Adhan library. Choose the method in Settings before release. */
class PrayerTimeCalculator {
    fun calculate(date: LocalDate, latitude: Double, longitude: Double, zone: ZoneId): Map<String, String> {
        val coordinates = Coordinates(latitude, longitude)
        val components = DateComponents(date.year, date.monthValue, date.dayOfMonth)
        val params = CalculationMethod.MUSLIM_WORLD_LEAGUE.parameters
        params.madhab = Madhab.SHAFI
        val times = PrayerTimes(coordinates, components, params)
        val formatter = DateTimeFormatter.ofPattern("HH:mm").withZone(zone)
        return linkedMapOf(
            "Fajr" to formatter.format(times.fajr.toInstant()),
            "Dhuhr" to formatter.format(times.dhuhr.toInstant()),
            "Asr" to formatter.format(times.asr.toInstant()),
            "Maghrib" to formatter.format(times.maghrib.toInstant()),
            "Isha" to formatter.format(times.isha.toInstant())
        )
    }
}
