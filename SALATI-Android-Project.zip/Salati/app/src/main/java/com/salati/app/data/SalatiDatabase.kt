package com.salati.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [PrayerRecord::class], version = 1, exportSchema = true)
abstract class SalatiDatabase : RoomDatabase() { abstract fun prayerDao(): PrayerDao }
