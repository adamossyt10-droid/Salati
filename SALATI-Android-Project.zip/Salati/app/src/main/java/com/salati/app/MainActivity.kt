package com.salati.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.salati.app.data.PrayerRecord
import com.salati.app.data.SalatiDatabase
import com.salati.app.data.PrayerRepository
import com.salati.app.domain.StreakCalculator
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Emerald = Color(0xFF075E45)
private val Gold = Color(0xFFD6B56D)
private val Cream = Color(0xFFF8F7F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, SalatiDatabase::class.java, "salati.db").build()
        val repository = PrayerRepository(db.prayerDao())
        setContent { SalatiTheme { SalatiApp(repository) } }
    }
}

@Composable private fun SalatiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Emerald, secondary = Gold, background = Cream, surface = Color.White), content = content)
}

@Composable private fun SalatiApp(repository: PrayerRepository) {
    val today = LocalDate.now()
    val scope = rememberCoroutineScope()
    val records by repository.observeRecords().collectAsState(initial = emptyList())
    val todayRecord = records.firstOrNull { it.date == today.toString() } ?: PrayerRecord(today.toString())
    val streak = remember(records) { StreakCalculator.calculate(records) }
    var selectedTab by remember { mutableIntStateOf(0) }
    Scaffold(containerColor = Cream, bottomBar = {
        NavigationBar(containerColor = Color.White) {
            val tabs = listOf("Home" to Icons.Rounded.Home, "Calendar" to Icons.Rounded.CalendarMonth, "Stats" to Icons.Rounded.Insights, "Settings" to Icons.Rounded.Settings)
            tabs.forEachIndexed { index, pair -> NavigationBarItem(selected = selectedTab == index, onClick = { selectedTab = index }, icon = { Icon(pair.second, contentDescription = pair.first) }, label = { Text(pair.first) }) }
        }
    }) { padding ->
        when (selectedTab) {
            0 -> HomeScreen(todayRecord, streak.current, streak.best, Modifier.padding(padding)) { name, checked -> scope.launch { repository.setPrayer(today, name, checked) } }
            1 -> HistoryScreen(records, Modifier.padding(padding))
            2 -> StatsScreen(records, streak.current, streak.best, Modifier.padding(padding))
            else -> SettingsScreen(Modifier.padding(padding))
        }
    }
}

@Composable private fun HomeScreen(record: PrayerRecord, current: Int, best: Int, modifier: Modifier = Modifier, onToggle: (String, Boolean) -> Unit) {
    val prayers = listOf(Triple("Fajr", "الفجر", record.fajrCompleted), Triple("Dhuhr", "الظهر", record.dhuhrCompleted), Triple("Asr", "العصر", record.asrCompleted), Triple("Maghrib", "المغرب", record.maghribCompleted), Triple("Isha", "العشاء", record.ishaCompleted))
    val done = record.completedCount()
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 28.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("SALATI", style = MaterialTheme.typography.labelLarge, color = Emerald, fontWeight = FontWeight.Bold)
            Text("السلام عليكم", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)), color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Today's progress", color = Color.White.copy(alpha = .8f))
                    Row(verticalAlignment = Alignment.Bottom) { Text("$done", color = Color.White, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold); Text(" / 5 prayers", color = Color.White, modifier = Modifier.padding(bottom = 9.dp, start = 8.dp)) }
                    LinearProgressIndicator(progress = { done / 5f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Gold, trackColor = Color.White.copy(alpha = .22f))
                    Text("${done * 20}% completed", color = Color.White)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("🔥  Current streak", fontWeight = FontWeight.SemiBold); Text("$current days", style = MaterialTheme.typography.titleLarge, color = Emerald, fontWeight = FontWeight.Bold) }
                    Column(horizontalAlignment = Alignment.End) { Text("Best streak", color = Color.Gray); Text("$best days", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item { Text("Daily prayers", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(prayers) { (english, arabic, checked) ->
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().animateContentSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(english, fontWeight = FontWeight.SemiBold); Text(arabic, color = Color.Gray) }
                    Checkbox(checked = checked, onCheckedChange = { onToggle(english, it) }, colors = CheckboxDefaults.colors(checkedColor = Emerald))
                }
            }
        }
        if (done == 5) item { Text("Alhamdulillah! All five prayers completed today.", color = Emerald, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable private fun HistoryScreen(records: List<PrayerRecord>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Prayer history", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (records.isEmpty()) Text("Your saved prayer days will appear here.", color = Color.Gray)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(records) { r -> Card { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.date); Text("${r.completedCount()}/5", color = Emerald, fontWeight = FontWeight.Bold) } } } }
    }
}

@Composable private fun StatsScreen(records: List<PrayerRecord>, current: Int, best: Int, modifier: Modifier = Modifier) {
    val total = records.sumOf { it.completedCount() }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Your progress", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        StatCard("Current streak", "$current days")
        StatCard("Best streak", "$best days")
        StatCard("Completed prayers", total.toString())
        StatCard("Fully completed days", records.count { it.isComplete() }.toString())
    }
}

@Composable private fun StatCard(label: String, value: String) { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(value, color = Emerald, fontWeight = FontWeight.Bold) } } }

@Composable private fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("SALATI 0.1.0", color = Emerald, fontWeight = FontWeight.Bold)
        Text("Prayer-time location, calculation method, notification scheduling, Adhan audio, language and theme controls are part of the next implementation phase.", color = Color.Gray)
    }
}
