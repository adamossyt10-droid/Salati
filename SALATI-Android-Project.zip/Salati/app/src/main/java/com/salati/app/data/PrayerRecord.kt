package com.salati.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "prayer_records")
data class PrayerRecord(
    @PrimaryKey val date: String, // ISO local date yyyy-MM-dd
    val fajrCompleted: Boolean = false,
    val dhuhrCompleted: Boolean = false,
    val asrCompleted: Boolean = false,
    val maghribCompleted: Boolean = false,
    val ishaCompleted: Boolean = false
) {
    fun completedCount() = listOf(fajrCompleted, dhuhrCompleted, asrCompleted, maghribCompleted, ishaCompleted).count { it }
    fun isComplete() = completedCount() == 5
}
