package com.salati.app.domain

import com.salati.app.data.PrayerRecord
import java.time.LocalDate

/** Streaks are derived from completed records. Today is provisional until its day ends. */
data class StreakSummary(val current: Int, val best: Int, val completedDays: Int)

object StreakCalculator {
    fun calculate(records: List<PrayerRecord>, today: LocalDate = LocalDate.now()): StreakSummary {
        val completed = records.asSequence().filter { it.isComplete() }
            .mapNotNull { runCatching { LocalDate.parse(it.date) }.getOrNull() }.toSortedSet()
        if (completed.isEmpty()) return StreakSummary(0, 0, 0)

        var best = 0
        var run = 0
        var previous: LocalDate? = null
        for (date in completed) {
            run = if (previous != null && previous.plusDays(1) == date) run + 1 else 1
            if (run > best) best = run
            previous = date
        }
        // A fully completed today counts immediately; otherwise the streak remains alive
        // through today if yesterday was complete. An unfinished current day is not a failure.
        val anchor = if (today in completed) today else today.minusDays(1)
        var current = 0
        var cursor = anchor
        while (cursor in completed) { current++; cursor = cursor.minusDays(1) }
        return StreakSummary(current, best, completed.size)
    }
}
