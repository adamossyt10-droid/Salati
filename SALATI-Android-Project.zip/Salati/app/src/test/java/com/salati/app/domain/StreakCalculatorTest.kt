package com.salati.app.domain

import com.salati.app.data.PrayerRecord
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class StreakCalculatorTest {
    @Test fun consecutiveDaysCountOncePerDate() {
        val rows = (1..3).map { PrayerRecord("2026-11-0$it", true, true, true, true, true) }
        val result = StreakCalculator.calculate(rows, LocalDate.parse("2026-11-03"))
        assertEquals(3, result.current)
        assertEquals(3, result.best)
    }
    @Test fun incompleteDayBreaksSequence() {
        val rows = listOf(
            PrayerRecord("2026-11-01", true, true, true, true, true),
            PrayerRecord("2026-11-02", true, true, true, true, false),
            PrayerRecord("2026-11-03", true, true, true, true, true)
        )
        val result = StreakCalculator.calculate(rows, LocalDate.parse("2026-11-03"))
        assertEquals(1, result.current)
        assertEquals(1, result.best)
    }
    @Test fun unfinishedTodayDoesNotBreakYesterdayStreak() {
        val rows = listOf(PrayerRecord("2026-11-20", true, true, true, true, true))
        val result = StreakCalculator.calculate(rows, LocalDate.parse("2026-11-21"))
        assertEquals(1, result.current)
    }
}
